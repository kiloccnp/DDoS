# Distributed Denial of Service (DDoS) Attack Scripts
This repo consists of various DDoS scripts, collected from internet. Layer-4 and Layer-7 levels can be targeted using these scripts.

Note: Scripts written in 'C' need to be compiled with GCC compiler, first.

Using these scripts, massive Distributed Denial of Service attacks can be launched against servers of all heights. These scripts can be used for load-testing applications or similar functions.

Disclaimer: Make sure you have a right permission to conduct DDoS attacks on the target system. These DDoS scripts are intended for testing purposes only. I'm not to be held responsible for any result arising from a DDoS attack launched using these scripts. 

~ Praneeth Karnena
